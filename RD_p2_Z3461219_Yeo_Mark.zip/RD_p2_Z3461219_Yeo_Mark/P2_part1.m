%Author: Mark Yeo , Z3461219
%Program: Solution for Project1.Part1

% MTRN4110 Project 2 Part 1
% Mark Yeo;  mark.yeo@student.unsw.edu.au
% Last Modified 2016/06/02


function main()

% === INITIALISATION ===
if true
    clc();

    % --- Global variables ---
    % (for sharing info between functions)
    global context;
    context=[] ; 
    context.Run=1;                  % a flag for indicating when to stop running
    context.Paused=0;               % .. for pausing
    context.ShowThis=[1,1,1];       % .. for showing certain visualization components.
    global TriaInfo;
    TriaInfo.mc = [];
    TriaInfo.mr = [];

    % --- Graph stuff ---
    % Depth data
    figure(1) ; clf();
    subplot(221);
    hd=imagesc(0); axis([0,640/4,0,480/4]); colormap gray;
    title('Deph Image') ;
    set(gca(),'xdir','reverse');
    CreateControlsInFigure(1) ;             % create some useful buttons, "GUI"
    % 3D points
    subplot(222);
    hPoints = plot3(0,0,0,'b.','markersize',1); hold on;
    hROI = plot3(0,0,0,'g.','markersize',2);
    hHOI = plot3(0,0,0,'r.','markersize',3);

    axis([0.3,1.5,-1,1,-0.05,0.5]);
    title('3D points (aligned)') ;
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    tmprp = [0,1;2,3];
    hFloorPlane = mesh(tmprp,tmprp,tmprp); % Plotting the surface
    hFloorNormal = quiver3(0.5,0,0,0,0,1,0.1);   % Plotting normal vector
    set(hFloorNormal,'linewidth',1);
    set(hFloorNormal,'color',[1,0,1]);

            
            
            
    % Attitude
    subplot(223);
    BufGyros = zeros(3,150);        %  "3 channels" buffer, for our "oscilloscope"
    hhi = [0,0,0];                  % handles
    % create 3 plotting objects
    hhi(1) = plot(BufGyros(1,:),'r'); hold on;  
    hhi(2) = plot(BufGyros(1,:),'Color', [0.5 0 0.5]);
    hhi(3) = plot(BufGyros(1,:),'Color', [0.8 0.8 0]);
    hold off;
    %axis([1,150,-40,40]);
    title('Attitude (in degrees)');
    %legend({'Rx','Ry','Rz'});
    xlabel('Time (seconds)');
    
    subplot(224);
    hLocHOI2D = plot(0,0,'.b','markersize',1);
    hold on;
    hLocPotPols = plot(0,0,'.r','markersize',6);
    hLocPols = plot(0,0,'*r','markersize',5);
    hLocLms = plot(0,0,'.g','markersize',10);
    axis([0.3,2.5,-1,1]); 
    axis equal ;
    camroll(90);
    xlabel('X (cm)'); ylabel('Y (cm)');
    title('Detection of Poles');

    
    
    
    MapFile = 'NavMap.mat';  

    load(MapFile) ;
    mapCoords = double(Landmarks.xy)/100; % metres
    mapN = Landmarks.n;
    
    figure(2) ; clf();
    
    % Estimated pitch & roll
    subplot(121);
    hEstRoll = plot(0,'r'); hold on;
    hEstPitch = plot(0,'Color', [0.5 0 0.5]);
    
    subplot (122);
        %subplot (223);
    OG.x1 = 0 ;OG.x2 = 1.90 ;
    OG.y1 = 0 ;OG.y2 = 1.90 ;
    OG.Nx = 38 ;
    OG.Ny = 38 ;
    % Create OG
    OG.M = zeros(OG.Ny,OG.Nx) ;
    hOG = imagesc(OG.M); hold on;
    colormap gray;
    set(gca,'ydir','normal','xdir','normal');
    %axis equal;

    kx = 37/(OG.x2-OG.x1);
    ky = 37/(OG.y2-OG.y1);
    
    hMap = plot(mapCoords(1,:)*kx+1, mapCoords(2,:)*ky+1, 'g.'); hold on;
    hLm = plot(0,0,'r.');
    axis equal;
    
    for i=1:mapN
        hLmText(i) = text(0, 0, '', 'Color', 'r');
    end
    hEstPosn = plot(0,0,'b');
    hEstHeading = plot(0,0,'r');
    
    origScale = linspace(0,38,5);
    newScale = linspace(0,1.9,5);
    set(gca,'XTick',origScale ); 
    set(gca,'XTickLabel',newScale );
    set(gca,'YTick',origScale ); 
    set(gca,'YTickLabel',newScale );
    %axislims = axis;
    %axis([0 1.9 0 1.9]);

    LCF = OG.M; % local cost function matrix
    
    
    % --- Initialize APIs ---
    % Init API for reading camera
    APIC=APICarmineC2();            % init API for reading remote Carmine data,
    if (APIC.ok<1), FailMessage() ; return ; end; % APIC to be used in subsequent calls
    % Init APIs for IMU readings + etc.
    APIu=API_PossumUGV2();
    if (APIu.Ok<1), FailMessage() ; return ; end;

    % --- Misc. API commands ---
    APIu.More.SendCmdToSimulator('restart');    % Restart Possum playback program
    % APIu.More.SendCmdToSimulator('jump 0')    % Rewind playback to time=0
    % APIu.More.SendCmdToSimulator('p');  % Pause simulator
    % APIu.More.SendCmdToSimulator('c');  % Continue simulator



    % --- Wait for IMU data to arrive before starting program ---
    ri = APIu.ReadIMU(1,1);   % read once to flush API's internal IMU buffers
    fprintf('Waiting for activity..\n'); 
    while context.Run,
        pause(0.2);
        ri = APIu.ReadIMU(1,1); % read last sample which arrived from IMU#1.
        if (ri.n>0),
            fprintf('Activity detected!. We carry on...\n');
            break;
        end
        continue;
    end;

    % --- Create rotation matrix ---
    a = +15.5 ; % camera has pitch inclination of +15.5deg (downwards) w.r.t. hexapod body
        % axes convention: of camera/platform
        % i.e. +ve pitch = rotation from +Z (up) to +X (ahead)
    a=a*pi/180; Ca=cos(a); Sa=sin(a);
    Ra = [ [Ca,0,+Sa];[0,1,0];[-Sa,0,Ca]];  % Rot matrix for pure rotation w.r.t. Y axis (pitch)
    clear a Ca Sa ;  % (not needed anymore)
end


% === GET SENSOR DATA ===

dt=0.1;	% pause time
tb=0;

imuAtts = [0;0;0];
imuN = 1;
imuT0 = -1; %in 1/10000th sec
imuWBias = [];
imuWBiasData = [];
imuTPrev = 0;
rToD = 180/pi;


imgT0 = -1;
imgHeights = [];
imgPitchs = [];
imgRolls = [];
imgRotMat = [];
imgPitchT0 = 0;
imgRollT0 = 0;
imgEstPitch = 0;
imgEstRoll = 0;


% init. agv posn: x0~ 25 cm ; y0~105 cm; Heading0 ~89 degrees.
agvPosnHist = [0.25; 1.05];
agvHeadHist = [];
agvPosn = [0.25; 1.05];
agvHeadT0 = 89/rToD;

% --- Main Loop ---
frameNo = 0;
while context.Run,
    frameNo = frameNo + 1;
    if true
        pause(dt);	% Execution rate
        if (context.Paused), pause(0.4); continue; end; % if paused, do nothing

        % --- Read sensors of interest ---
        [nc,tc,M]=APIC.ReadLastDFrame();	%read new depth data if it exists
            % nc>0 : new image is available, 
            % tc: timestamp of image, 
            % M: Depth image.
        ri = APIu.ReadIMU(1,100);   %read up to 100 IMU's measurements from IMU device 1
        ni = ri.n;  % # IMU samples read
        % fprintf('[%d]\n',ni);
    end
    
    % === PROCESS IMU DATA ===
    if (ni>0)
        
        %fprintf('We have read [%d] IMU samples\n',ni);
        %timesI = ri.tcx(1,1:ni);
        Gyros  = ri.data(4:6,1:ni)*180/pi;  % deg/sec
        % "ri.data(4:6,1:ni)": contains the "ni" measurements from gyroscopes.
        % "ri.tcx(1,1:ni)" : the associated timestamps of those measurements.
        
        if context.ShowThis(1)     % If oscilloscope enabled
            % --- Fill shifting gyro buffer ---
            BufGyros(:,1:end-ni)=BufGyros(:,ni+1:end);
            BufGyros(:,end-ni+1:end)=Gyros;        
            tb=tb+dt;
            if tb>0.20
                % --- Refresh oscilloscope periodically ---
                tb=0 ;
            end;
        end;
        
        % --- Process gyro data ---
        
        % record t0
        if imuT0 == -1
            imuT0 = ri.tcx(1,1);
        end
        
        % convert data to nice numbers
        wTimes = double(ri.tcx(1,1:ni) - imuT0);
        wTimes = wTimes/10000;
        wData = double(ri.data(4:6,1:ni));
        
        % do a bias thing
        if wTimes(end) < 15
            imuWBiasData = [imuWBiasData wData];
        end
        if wTimes(end) > 16 & wTimes(end) < 28
            %wBiasData = [wBiasData wData];
        end
        
        imuWBias = mean(imuWBiasData, 2);
        wx = wData(1,:) - imuWBias(1);
        wy = wData(2,:) - imuWBias(2);
        wz = wData(3,:) - imuWBias(3);
        wData = [wx; wy; wz];
        
        % average ws, put in vertical 3-array
        ws = mean(wData, 2);
        imuDt = wTimes(end) - imuTPrev;
        imuTPrev = wTimes(end);
        imuAtts = [imuAtts getnextAtt(ws(:),imuAtts(:,imuN), imuDt)];
        imuN = imuN + 1;
        
        imuTimes = linspace(0,wTimes(end), imuN);
        set(hhi(1),'xdata', imuTimes, 'ydata',imuAtts(1,:)*rToD);
        set(hhi(2),'xdata', imuTimes, 'ydata',imuAtts(2,:)*rToD);
        set(hhi(3),'xdata', imuTimes, 'ydata',imuAtts(3,:)*rToD);

        
        
        
    else
        % No IMU data (measurements generated > 100HZ)
    end;

    
   % === PROCESS DEPTH DATA ===
    if (nc>0)
        if true
            % --- Rotate points to align with floor ---
            [xx,yy,zz]=APIC.ConvertDepthsTo3DPoints(M);  % Convert depths to 3D points
            % convert to aligned coordinate frame (aligned with the floor (assumed to be horizontal))
            L = numel(xx);
            xx2=reshape(xx,1,L); % pack in 3xL matrix to be multiplied by left rot matrix
            yy2=reshape(yy,1,L);
            zz2=reshape(zz,1,L);
            pp = Ra*[xx2;yy2;zz2];
            xx2 = pp(1,:); yy2=pp(2,:); zz2=pp(3,:);


            % --- Process depth data ---

            if imgT0 == -1
                imgT0 = tc;
            end
            imgTime = double(tc - imgT0)/10000;


            % extract ROI from xx, yy, zz
            xxf = xx2(:)'; yyf = yy2(:)'; zzf = zz2(:)';
            roiXMin = 0.3;
            roiXMax = 0.6;
            roiYMin = -0.15;
            roiYMax = 0.15;

            xfltr = xxf<roiXMax & xxf>roiXMin;
            yfltr = yyf<roiYMax & yyf>roiYMin;
            fltr = xfltr & yfltr;
            xxf = xxf(fltr); yyf = yyf(fltr); zzf = zzf(fltr); 
            if imgTime < 15
                imgHeights = mean(zzf);
            end
            imgMeanHeight = mean(imgHeights);
            zzf = zzf - imgMeanHeight;
            zz2 = zz2 - imgMeanHeight;
            fltr = zzf < 0.02;
            xxf = xxf(fltr); yyf = yyf(fltr); zzf = zzf(fltr); 
            zave = mean(zzf);
            fltr = zzf<zave;
            xxf = xxf(fltr); yyf = yyf(fltr); zzf = zzf(fltr); 





            % Calculate rotation matrix
                % X = x;
                % Y = y*cos(p)-z*sin(p);
                % Z = y*sin(p)+z*cos(p);
            thx = imgEstRoll;
            thy = imgEstPitch;
            thz = 0;
            sinx = sin(thx); cosx = cos(thx);
            siny = sin(thy); cosy = cos(thy);
            sinz = sin(thz); cosz = cos(thz);

            imgRotMat = [cosy*cosz -cosx*sinz+sinx*siny*cosz sinx*sinz+cosx*siny*cosz;
                 cosy*sinz cosx*cosz+sinx*siny*sinz  -sinx*cosz+cosx*siny*sinz;
                 -siny      sinx*cosy                 cosx*cosy];

            % Apply rotation matrix

            tmprp = imgRotMat*[xx2; yy2; zz2];
            xx2 = tmprp(1,:);
            yy2 = tmprp(2,:);
            zz2 = tmprp(3,:);







            % --- Detect poles ---
            % Select height range of interest
            fltr = zz2>0.1 & zz2<0.2;
            xxp = xx2(fltr)'; yyp = yy2(fltr)'; zzp = zz2(fltr)';  
            % Order 2D points w.r.t. angle from camera's viewpoint
            pointang = atan(yyp./xxp);
            data = [xxp,yyp,zzp,pointang];
            data = sortrows(data,4);
            xxp = data(:,1); yyp = data(:,2); zzp = data(:,3);
            % Find poles
            xxrp = [];
            yyrp = [];
            grpthresh = 0.05; % threshold distance for point clustering
            xgrp = [xxp(1)];
            ygrp = [yyp(1)];
            for i=2:size(xxp)
                % cluster adjacent points until non-adjacent point found
                ptdist = sqrt((xxp(i)-xxp(i-1))^2+(yyp(i)-yyp(i-1))^2);
                if ptdist < grpthresh   % if within cluster threshold:
                    xgrp = [xgrp xxp(i)];
                    ygrp = [ygrp yyp(i)];
                else                    % if outside of cluster threshold:
                    % process last group
                    xysize = max((max(xgrp)-min(xgrp)), (max(ygrp)-min(ygrp)));
                    if xysize > 0.01 && xysize < 0.10
                        xxrp = [xxrp mean(xgrp)];
                        yyrp = [yyrp mean(ygrp)];
                    end
                    % overwrite last group w/ current point
                    xgrp = [xxp(i)];
                    ygrp = [yyp(i)];
                    shiny = 0;
                end
            end


            fltr = xxrp > roiXMin & xxrp < roiXMax & yyrp > roiYMin & yyrp < roiYMax; 
            
            if sum(fltr, 2) == 0    % If there's no 'risky objects' in your ROI,
                % Calculate plane of best fit of ROI
                coeffs = [xxf' yyf' ones(size(xxf'))]\zzf'; % Find plane coeffs using backslash operator (least squares)
                xcoeff = coeffs(1); % X coefficient
                ycoeff = coeffs(2); % Y coefficient
                ccoeff = coeffs(3); % constant term

                % Generate mesh to display plane of best fit
                    % xcoeff*x + ycoeff*y - z + ccoeff = 0
                [xxs, yys]=meshgrid(0.2:0.05:0.8,-0.5:0.05:0.5); % Generating a regular grid for plotting
                zzs = xcoeff * xxs + ycoeff * yys + ccoeff;

                % Calculate inclination of ground plane w.r.t. sensor
                    % Assumes yaw (theta z) = 0 deg
                    % (We could use the rotation matrix but since thetaz is = 0
                    % we just use atan2), i.e.
                    % angle = atan2(-xcoeff,1)
                    % instead of:
                    % ax   -sin(thetay)
                    % ay = cos(thetay)*sin(thetax)
                    % az   cos(thetay)*cos(thetax)

                imgEstPitch = real(asin(xcoeff));
                imgEstRoll = real(asin(ycoeff/cos(imgEstPitch)));
                if isempty(imgPitchs)
                    imgPitchT0 = imgEstPitch;
                    imgRollT0 = imgEstRoll;
                    imgEstPitch = 0;
                    imgEstRoll = 0;
                else
                    imgEstPitch = imgEstPitch - imgPitchT0;
                    imgEstRoll = imgEstRoll - imgRollT0;
                end
                imuAtts(2,end) = imgEstPitch;
                imuAtts(1,end) = imgEstRoll;
                pit = imgEstPitch * rToD;
                rol = imgEstRoll * rToD;
                imgPitchs = [imgPitchs imgEstPitch];
                imgRolls = [imgRolls imgEstRoll];
            else
                [xxs,yys] = meshgrid(0.2:0.201,-0.5:-0.499);
                zzs = xxs;
                xcoeff = 0;
                ycoeff = 0;
                imgPitchs = [imgPitchs imgPitchs(end)];
                imgRolls = [imgRolls imgRolls(end)];
            end
        end
        
        
        % --- Associate risky point data ---
        cullDist = 0.25; % metres % 0.05 is tight
        if ~isempty(xxrp)
            % translate risky points to global coord frame
            tmprp = [xxrp; yyrp];   % temp risky points to be converted to global coord frame
            agvHead = agvHeadT0 - imuAtts(3,end); % imu is mounted upside down
            R = [cos(agvHead), -sin(agvHead); sin(agvHead), cos(agvHead)];
            for i=1:size(tmprp,2)
                tmprp(:,i) = R * tmprp(:,i);
                tmprp(:,i) = tmprp(:,i) + [agvPosn(1); agvPosn(2)];
            end
            % cull risky points that are too far away from landmarks
            tmprp2 = [];    % temp risky points to be culled
            for i=1:size(tmprp,2)
                for j=1:mapN
                    boxDist = 0.07;
                    if tmprp(1,i) > -boxDist & tmprp(1,i) < 1.9+boxDist & tmprp(2,i) > -boxDist & tmprp(2,i) < 1.9+boxDist
                        d = sqrt((tmprp(1,i)-mapCoords(1,j))^2+(tmprp(2,i)-mapCoords(2,j))^2);
                        if d < cullDist
                            tmprp2 = [tmprp2 tmprp(:,i)];
                        end
                    end
                end
            end
            xxLmG = [];
            yyLmG = [];
            idlm = [];
            xxLmL = [];
            yyLmL = [];
            
            % Associate closest risky points to landmarks
            if ~isempty(tmprp2)
                lmAndPols = [mapCoords'; tmprp2'];
                D1 = pdist(lmAndPols,'euclidean');
                D2 = squareform(D1);
                for i=1:mapN
                    m = min(D2(mapN+1:end,i));
                    if m < cullDist
                        lmi = find(D2(mapN+1:end,i) == m, 1);
                        xxLmG = [xxLmG tmprp2(1,lmi)];    % measured landmarks (global)
                        yyLmG = [yyLmG tmprp2(2,lmi)];
                        idlm = [idlm i];
                        tmprp3 = tmprp2;    % temp risky points to be converted back to local coord frame
                        for i=1:size(tmprp3,2)
                            tmprp3(:,i) = tmprp3(:,i) - [agvPosn(1); agvPosn(2)];
                            tmprp3(:,i) = R' * tmprp3(:,i);
                        end
                        for i=1:size(mapCoords,2)
                            mapCoordsLocal(:,i) = mapCoords(:,i) - [agvPosn(1); agvPosn(2)]; %change this?
                            mapCoordsLocal(:,i) = R' * mapCoordsLocal(:,i);
                        end
                        xxLmL = [xxLmL tmprp3(1,lmi)];   % measured landmarks (local)
                        yyLmL = [yyLmL tmprp3(2,lmi)];
                    end
                end
                
                
                % --- Estimate state ---
                % Triangulate position from rp-landmark pairs
                options =  optimset('TolFun',1e-4,'TolX',1e-4); % tolerance of 0.001 in cost fn
                
                measuredRanges = sqrt(xxLmL.*xxLmL + yyLmL.*yyLmL);
                TriaInfo.mc = mapCoords(:,idlm);
                TriaInfo.mr = measuredRanges;
                
                estPosn = fminsearch(@TriangulationCostFn,agvPosn,options);
                tempx = mean([agvPosnHist(1,max(1,end-1)), agvPosnHist(1,end), estPosn(1)]);
                tempy = mean([agvPosnHist(2,max(1,end-1)), agvPosnHist(2,end), estPosn(2)]); %more history?
                %tempx = estPosn(1);
                %tempy = estPosn(2);
                agvPosn = [tempx;tempy];
                agvPosnHist = [agvPosnHist agvPosn];
                
                % Calibrate yaw
                
                if size(xxLmG,2) >= 2 & imgTime > 40 & imgTime < 41
                    dy = yyLmG(2)-yyLmG(1);
                    dx = xxLmG(2)-xxLmG(1);
                    estYaw = atan(dy/dx) + pi/2;
                    estYaw * rToD
                    imuAtts(3,end) = mean([imuAtts(3,end), estYaw, estYaw]);
                end
                


                
                if mod(frameNo,10) == 1
                    % --- Form occupancy grid ---

                    OG.Cx = OG.Nx/(OG.x2-OG.x1);   % Constants for scaling (x,y) points to cell indexes
                    OG.Cy = OG.Ny/(OG.y2-OG.y1);

                    ogX = tmprp(1,:); ogY = tmprp(2,:);

                    % Populate OG w/ risky points
                    ii = find((ogX>=OG.x1)&(ogX<OG.x2)&(ogY>=OG.y1)&(ogY<OG.y2)); % Filter out points outside of OG
                    ogX=ogX(ii) ; ogY=ogY(ii);
                    ix = floor((ogX-OG.x1)*OG.Cx)+1; % Convert to 2D indexes
                    iy = floor((ogY-OG.y1)*OG.Cy)+1;
                    ixy = sub2ind(size(OG.M),iy,ix); % Convert to OG indexes
                    OG.M(ixy) = 20; % Set value of cells

                    % Populate OG w/ clear paths
                    ogX = [];
                    ogY = [];
                    for i=1:size(tmprp,2)
                        ogX = [ogX linspace(agvPosn(1),tmprp(1,i),OG.Nx)];
                        ogY = [ogY linspace(agvPosn(2),tmprp(2,i),OG.Ny)];
                    end

                    %ogX = [0.1 1.2];
                    %ogY = [0.3 1.4];
                    ii = find((ogX>=OG.x1)&(ogX<OG.x2)&(ogY>=OG.y1)&(ogY<OG.y2)); % Filter out points outside of OG
                    ogX=ogX(ii) ; ogY=ogY(ii);
                    ix = floor((ogX-OG.x1)*OG.Cx)+1;
                    iy = floor((ogY-OG.y1)*OG.Cy)+1;
                    ixy = sub2ind(size(OG.M),iy,ix);
                    OG.M(ixy) = OG.M(ixy) - 0.5; % Set value of cells
                    fltr = OG.M == -0.5 | OG.M == 9.5;
                    OG.M(fltr) = 10;
                    
                    
                    
                    LCF = OG.M;
                    for value = 10.5:0.5:20
                        for i = 1:38
                            for j = 1:38
                                if LCF(i,j) == value
                                    expand = int8(15/5);
                                    is = [i-expand:i+expand];%[i-3:i+3,      i-2:i+2,        i-2:i+2];%,        i-1:i+1,        i-1:i+1,        ones(1,7)*i];
                                    js = [j-expand:j+expand];%[ones(1,7)*j,  ones(1,5)*j-1, ones(1,5)*j+1];%,   ones(1,3)*j-2, ones(1,3)*j+2,       j-3:j+3];
                                    fltr = is >= 1 & is <= 38 & js >= 1 & js <= 38;
                                    is = is(fltr);
                                    js = js(fltr);
                                    LCF(is,js) = 30;
                                end
                            end
                        end
                        fltr = LCF == 30;
                        LCF(fltr) = value;
                    end
                    
                    
                    
                    
                    
                end

            end
        end
        
        
        
        % --- Visualise depth data ---
        %set(hd,'cdata',[]);
        %M(1)=0; M(2)=3000; 
        %set(hd,'cdata',M);
        set(hPoints,'xdata',xx2,'ydata',yy2,'zdata',zz2);
        
        set(hROI,'xdata',xxf,'ydata',yyf,'zdata',zzf);
        set(hFloorPlane,'xdata',xxs,'ydata',yys,'zdata',zzs);
        set(hFloorNormal,'udata',-xcoeff,'vdata',-ycoeff);
        
        set(hHOI,'xdata',xxp,'ydata',yyp,'zdata',zzp);
        set(hLocHOI2D,'xdata',xxp,'ydata',yyp);
        set(hLocPotPols,'xdata',xxrp,'ydata',yyrp);
        set(hLocPols,'xdata',xxLmL,'ydata',yyLmL);
        set(hLocLms,'xdata',mapCoordsLocal(1,:),'ydata',mapCoordsLocal(2,:));
        
        
        imgRPTimes = linspace(0,imgTime, size(imgPitchs,2));
        set(hEstRoll,'xdata', imgRPTimes, 'ydata',imgRolls*rToD);
        set(hEstPitch,'xdata', imgRPTimes, 'ydata',imgPitchs*rToD);
        
        set(hLm,'xdata',xxLmG*kx+1,'ydata',yyLmG*ky+1);
        for i=1:mapN
            set(hLmText(i),'string','');
        end
        
        for i=1:size(idlm,2)
            s = sprintf('Pole %d',idlm(i));
            set(hLmText(i),'position',[xxLmG(i)*kx+1, yyLmG(i)*ky+1],'string',s);
        end
        set(hEstPosn,'xdata', agvPosnHist(1,:)*kx+1, 'ydata', agvPosnHist(2,:)*ky+1);

        set(hEstHeading,'xdata', agvPosnHist(1,end)*kx+1, 'ydata', agvPosnHist(2,:)*ky+1);
        
        imuAtts(3,end)
        % Display OG                
        %set(hOG, 'cdata', LCF);
        set(hOG, 'cdata', OG.M);

    end
end
fprintf('Bye!\n');
close(1);
return
end



function cost = TriangulationCostFn(z)
    % 'z' specified by the optimiser.
    global TriaInfo; %.LandmarksCentersX;
    mapPoles = TriaInfo.mc;
    measuredRanges = TriaInfo.mr;
    % Evaluate equations for the proposed hypothesis 'z'
    dxs = mapPoles(1,:) - z(1);
    dys = mapPoles(2,:) - z(2);
    hypothesisRanges =  sqrt(dxs.*dxs+dys.*dys);

    err = measuredRanges - hypothesisRanges ;
    cost = sum(err.^2);
    return;
end



function nextAtt = getnextAtt(ws, ang, dt)
    wx = ws(1);
    wy = ws(2);
    wz = ws(3);
    cosang1=cos(ang(1)) ;
    cosang2=cos(ang(2)) ;
    sinang1=sin(ang(1)) ;
    roll = ang(1) + dt * (wx + (wy*sinang1 + wz*cosang1)*tan(ang(2))) ; %(*)
    pitch = ang(2) + dt * (wy*cosang1 - wz*sinang1) ;
    yaw = ang(3) + dt * ((wy*sinang1 + wz*cosang1)/cosang2) ; %(*)
    nextAtt = [roll,pitch,yaw]';
end

































% === INIT FUNCTIONS ===

% Create GUI controls
function hh=CreateControlsInFigure(fff)
    figure(fff);
    hy = 20;  px=10;hh=zeros(4,1)-1; currF1=1;ddx=80 ;
    hh(1) = CreateOneButton('BYE',[px, currF1, ddx, hy],{@CallBack_Bye});
    px=px+ddx+5;
    hh(2) = CreateOneButton('Pause/Continue',[px, currF1, ddx, hy],{@CallBack_Pause});
    return;
end
function h = CreateOneButton(strBla,position,MyCallback)
    h=uicontrol('Style','pushbutton','String',strBla,'Position',position, 'Callback',MyCallback);        
    return
end

% Callback functions for GUI controls
function CallBack_Bye(~,~)
    global context; context.Run=0; return;    
end
function CallBack_Pause(~,~)
    global context;
    if ~context.Paused,  context.Paused=1; str='Paused' ; 
    else                 context.Paused=0; str='Continue' ; 
    end;
    fprintf('-->%s\n',str);
return;    
end

% Create fail message
function FailMessage()
    fprintf('API initialization failed\n');
    fprintf('Remember to have Possum.exe running\n');
    fprintf('Do "clear all" and run this program again.\n');
end
